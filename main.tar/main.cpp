#include <iostream>

int main(int argc, char** argv) {
    std::cout << "Hello, world!" << std::endl;
    std::cerr << "Ayyyy lmao" << std::endl;
    std::cout << "Hello, world!" << std::endl;
    std::cerr << "Ayyyy lmao" << std::endl;
}